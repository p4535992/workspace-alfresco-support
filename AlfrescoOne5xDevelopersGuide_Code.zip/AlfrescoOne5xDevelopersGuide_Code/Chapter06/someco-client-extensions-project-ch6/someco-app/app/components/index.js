System.register(['./search/search.component', './search/search-bar.component', './login/login-demo.component', './tasks/activiti-demo.component', './files/files.component', './chart/chart.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    return {
        setters:[
            function (search_component_1_1) {
                exports_1({
                    "SearchComponent": search_component_1_1["SearchComponent"]
                });
            },
            function (search_bar_component_1_1) {
                exports_1({
                    "SearchBarComponent": search_bar_component_1_1["SearchBarComponent"]
                });
            },
            function (login_demo_component_1_1) {
                exports_1({
                    "LoginDemoComponent": login_demo_component_1_1["LoginDemoComponent"]
                });
            },
            function (activiti_demo_component_1_1) {
                exports_1({
                    "ActivitiDemoComponent": activiti_demo_component_1_1["ActivitiDemoComponent"]
                });
            },
            function (files_component_1_1) {
                exports_1({
                    "FilesComponent": files_component_1_1["FilesComponent"]
                });
            },
            function (chart_component_1_1) {
                exports_1({
                    "ChartComponent": chart_component_1_1["ChartComponent"]
                });
            }],
        execute: function() {
        }
    }
});
//# sourceMappingURL=index.js.map