System.register(['@angular/core', 'ng2-activiti-tasklist', 'ng2-activiti-processlist', 'ng2-activiti-form'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, ng2_activiti_tasklist_1, ng2_activiti_processlist_1, ng2_activiti_form_1;
    var ActivitiDemoComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (ng2_activiti_tasklist_1_1) {
                ng2_activiti_tasklist_1 = ng2_activiti_tasklist_1_1;
            },
            function (ng2_activiti_processlist_1_1) {
                ng2_activiti_processlist_1 = ng2_activiti_processlist_1_1;
            },
            function (ng2_activiti_form_1_1) {
                ng2_activiti_form_1 = ng2_activiti_form_1_1;
            }],
        execute: function() {
            ActivitiDemoComponent = (function () {
                function ActivitiDemoComponent() {
                    this.currentChoice = 'task-list';
                    this.taskSchemaColumns = [];
                    this.processSchemaColumns = [];
                    this.taskSchemaColumns = [
                        { type: 'text', key: 'name', title: 'Name', cssClass: 'full-width name-column', sortable: true }
                    ];
                    this.processSchemaColumns = [
                        { type: 'text', key: 'name', title: 'Name', cssClass: 'full-width name-column', sortable: true }
                    ];
                }
                ActivitiDemoComponent.prototype.setChoice = function ($event) {
                    this.currentChoice = $event.target.value;
                };
                ActivitiDemoComponent.prototype.isProcessListSelected = function () {
                    return this.currentChoice === 'process-list';
                };
                ActivitiDemoComponent.prototype.isTaskListSelected = function () {
                    return this.currentChoice === 'task-list';
                };
                ActivitiDemoComponent.prototype.onTaskFilterClick = function (event) {
                    this.taskFilter = event;
                    this.activititasklist.load(this.taskFilter);
                };
                ActivitiDemoComponent.prototype.onProcessFilterClick = function (event) {
                    this.processFilter = event.filter;
                    this.activitiprocesslist.load(this.processFilter);
                };
                ActivitiDemoComponent.prototype.onTaskRowClick = function (taskId) {
                    this.currentTaskId = taskId;
                    this.activitidetails.loadDetails(this.currentTaskId);
                };
                ActivitiDemoComponent.prototype.onProcessRowClick = function (processInstanceId) {
                    this.currentProcessInstanceId = processInstanceId;
                    this.activitiprocessdetails.load(this.currentProcessInstanceId);
                };
                ActivitiDemoComponent.prototype.processCancelled = function (data) {
                    this.currentProcessInstanceId = null;
                    this.activitiprocesslist.reload();
                };
                ActivitiDemoComponent.prototype.taskFormCompleted = function (data) {
                    this.activitiprocesslist.reload();
                };
                ActivitiDemoComponent.prototype.ngAfterViewChecked = function () {
                    // workaround for MDL issues with dynamic components
                    if (componentHandler) {
                        componentHandler.upgradeAllRegistered();
                    }
                };
                __decorate([
                    core_1.ViewChild('activitidetails'), 
                    __metadata('design:type', Object)
                ], ActivitiDemoComponent.prototype, "activitidetails", void 0);
                __decorate([
                    core_1.ViewChild('activititasklist'), 
                    __metadata('design:type', Object)
                ], ActivitiDemoComponent.prototype, "activititasklist", void 0);
                __decorate([
                    core_1.ViewChild('activitiprocesslist'), 
                    __metadata('design:type', Object)
                ], ActivitiDemoComponent.prototype, "activitiprocesslist", void 0);
                __decorate([
                    core_1.ViewChild('activitiprocessdetails'), 
                    __metadata('design:type', Object)
                ], ActivitiDemoComponent.prototype, "activitiprocessdetails", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], ActivitiDemoComponent.prototype, "appId", void 0);
                ActivitiDemoComponent = __decorate([
                    core_1.Component({
                        moduleId: __moduleName,
                        selector: 'activiti-demo',
                        templateUrl: './activiti-demo.component.html',
                        styleUrls: ['./activiti-demo.component.css'],
                        directives: [ng2_activiti_tasklist_1.ALFRESCO_TASKLIST_DIRECTIVES, ng2_activiti_processlist_1.ACTIVITI_PROCESSLIST_DIRECTIVES, ng2_activiti_form_1.ActivitiForm]
                    }), 
                    __metadata('design:paramtypes', [])
                ], ActivitiDemoComponent);
                return ActivitiDemoComponent;
            }());
            exports_1("ActivitiDemoComponent", ActivitiDemoComponent);
        }
    }
});
//# sourceMappingURL=activiti-demo.component.js.map