
export { SearchComponent } from './search/search.component';
export { SearchBarComponent } from './search/search-bar.component';
export { LoginDemoComponent } from './login/login-demo.component';
export { ActivitiDemoComponent } from './tasks/activiti-demo.component';
export { FilesComponent } from './files/files.component';
export { ChartComponent } from './chart/chart.component';
