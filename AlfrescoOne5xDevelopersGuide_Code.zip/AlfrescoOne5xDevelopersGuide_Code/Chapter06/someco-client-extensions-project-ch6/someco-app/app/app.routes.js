System.register(['@angular/router', './components/index'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var router_1, index_1;
    var routes, appRouterProviders;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (index_1_1) {
                index_1 = index_1_1;
            }],
        execute: function() {
            exports_1("routes", routes = [
                { path: 'home', component: index_1.FilesComponent },
                { path: 'search', component: index_1.SearchComponent },
                { path: 'files', component: index_1.FilesComponent },
                { path: 'activiti', component: index_1.ActivitiDemoComponent },
                { path: 'chart', component: index_1.ChartComponent },
                { path: '', component: index_1.LoginDemoComponent },
                { path: 'login', component: index_1.LoginDemoComponent }
            ]);
            exports_1("appRouterProviders", appRouterProviders = [
                router_1.provideRouter(routes)
            ]);
        }
    }
});
//# sourceMappingURL=app.routes.js.map