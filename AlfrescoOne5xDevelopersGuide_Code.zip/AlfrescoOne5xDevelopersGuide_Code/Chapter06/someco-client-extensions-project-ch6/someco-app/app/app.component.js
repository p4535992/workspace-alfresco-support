System.register(['@angular/core', '@angular/router', 'ng2-alfresco-core', './components/index'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, ng2_alfresco_core_1, index_1;
    var AppComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (ng2_alfresco_core_1_1) {
                ng2_alfresco_core_1 = ng2_alfresco_core_1_1;
            },
            function (index_1_1) {
                index_1 = index_1_1;
            }],
        execute: function() {
            AppComponent = (function () {
                function AppComponent(auth, router, translate, alfrescoSettingsService) {
                    this.auth = auth;
                    this.router = router;
                    this.alfrescoSettingsService = alfrescoSettingsService;
                    this.searchTerm = '';
                    this.ecmHost = 'http://127.0.0.1:8080';
                    this.bpmHost = 'http://127.0.0.1:9999';
                    this.setEcmHost();
                    this.setBpmHost();
                    this.translate = translate;
                    this.translate.addTranslationFolder();
                }
                AppComponent.prototype.onChangeECMHost = function (event) {
                    console.log(event.target.value);
                    this.ecmHost = event.target.value;
                    this.alfrescoSettingsService.ecmHost = this.ecmHost;
                    localStorage.setItem("ecmHost", this.ecmHost);
                };
                AppComponent.prototype.onChangeBPMHost = function (event) {
                    console.log(event.target.value);
                    this.bpmHost = event.target.value;
                    this.alfrescoSettingsService.bpmHost = this.bpmHost;
                    localStorage.setItem("bpmHost", this.bpmHost);
                };
                AppComponent.prototype.isLoggedIn = function () {
                    return this.auth.isLoggedIn();
                };
                AppComponent.prototype.onLogout = function (event) {
                    var _this = this;
                    event.preventDefault();
                    this.auth.logout()
                        .subscribe(function () { return _this.router.navigate(['/login']); });
                };
                AppComponent.prototype.onToggleSearch = function (event) {
                    var expandedHeaderClass = 'header-search-expanded', header = document.querySelector('header');
                    if (event.expanded) {
                        header.classList.add(expandedHeaderClass);
                    }
                    else {
                        header.classList.remove(expandedHeaderClass);
                    }
                };
                AppComponent.prototype.changeLanguage = function (lang) {
                    this.translate.use(lang);
                };
                AppComponent.prototype.hideDrawer = function () {
                    // todo: workaround for drawer closing
                    document.querySelector('.mdl-layout').MaterialLayout.toggleDrawer();
                };
                AppComponent.prototype.setEcmHost = function () {
                    if (localStorage.getItem("ecmHost")) {
                        this.alfrescoSettingsService.ecmHost = localStorage.getItem("ecmHost");
                        this.ecmHost = localStorage.getItem("ecmHost");
                    }
                    else {
                        this.alfrescoSettingsService.ecmHost = this.ecmHost;
                    }
                };
                AppComponent.prototype.setBpmHost = function () {
                    if (localStorage.getItem("bpmHost")) {
                        this.alfrescoSettingsService.bpmHost = localStorage.getItem("bpmHost");
                        this.bpmHost = localStorage.getItem("bpmHost");
                    }
                    else {
                        this.alfrescoSettingsService.bpmHost = this.bpmHost;
                    }
                };
                AppComponent = __decorate([
                    core_1.Component({
                        selector: 'alfresco-app',
                        templateUrl: 'app/app.component.html',
                        styleUrls: ['app/app.component.css'],
                        directives: [index_1.SearchBarComponent, router_1.ROUTER_DIRECTIVES, ng2_alfresco_core_1.MDL],
                        pipes: [ng2_alfresco_core_1.AlfrescoPipeTranslate]
                    }), 
                    __metadata('design:paramtypes', [ng2_alfresco_core_1.AlfrescoAuthenticationService, router_1.Router, ng2_alfresco_core_1.AlfrescoTranslationService, ng2_alfresco_core_1.AlfrescoSettingsService])
                ], AppComponent);
                return AppComponent;
            }());
            exports_1("AppComponent", AppComponent);
        }
    }
});
//# sourceMappingURL=app.component.js.map