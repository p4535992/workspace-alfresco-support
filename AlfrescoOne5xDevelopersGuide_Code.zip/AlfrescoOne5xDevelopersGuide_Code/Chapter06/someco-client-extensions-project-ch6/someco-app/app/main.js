System.register(['@angular/platform-browser-dynamic', '@angular/router-deprecated', '@angular/http', './app.component', 'ng2-alfresco-core', 'ng2-alfresco-search', 'ng2-alfresco-upload', 'ng2-activiti-form', './app.routes'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var platform_browser_dynamic_1, router_deprecated_1, http_1, app_component_1, ng2_alfresco_core_1, ng2_alfresco_search_1, ng2_alfresco_upload_1, ng2_activiti_form_1, app_routes_1;
    return {
        setters:[
            function (platform_browser_dynamic_1_1) {
                platform_browser_dynamic_1 = platform_browser_dynamic_1_1;
            },
            function (router_deprecated_1_1) {
                router_deprecated_1 = router_deprecated_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (app_component_1_1) {
                app_component_1 = app_component_1_1;
            },
            function (ng2_alfresco_core_1_1) {
                ng2_alfresco_core_1 = ng2_alfresco_core_1_1;
            },
            function (ng2_alfresco_search_1_1) {
                ng2_alfresco_search_1 = ng2_alfresco_search_1_1;
            },
            function (ng2_alfresco_upload_1_1) {
                ng2_alfresco_upload_1 = ng2_alfresco_upload_1_1;
            },
            function (ng2_activiti_form_1_1) {
                ng2_activiti_form_1 = ng2_activiti_form_1_1;
            },
            function (app_routes_1_1) {
                app_routes_1 = app_routes_1_1;
            }],
        execute: function() {
            platform_browser_dynamic_1.bootstrap(app_component_1.AppComponent, [
                router_deprecated_1.ROUTER_PROVIDERS,
                app_routes_1.appRouterProviders,
                ng2_alfresco_upload_1.UploadService,
                http_1.HTTP_PROVIDERS,
                ng2_alfresco_search_1.ALFRESCO_SEARCH_PROVIDERS,
                ng2_activiti_form_1.ATIVITI_FORM_PROVIDERS,
                ng2_alfresco_core_1.ALFRESCO_CORE_PROVIDERS
            ]);
        }
    }
});
//# sourceMappingURL=main.js.map