This folder (root in the AMP) gets mapped automagically in WEB-INF/licenses
by the MMT or the alfresco-maven-plugin