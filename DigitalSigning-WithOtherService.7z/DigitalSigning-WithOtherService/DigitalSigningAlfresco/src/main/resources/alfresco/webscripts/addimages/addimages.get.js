function main() {
//importPackage(Packages.org.mozilla.javascript);
//java -jar alfresco-mmt.jar install C:\Alfresco\amps_share\alfresco-signature-share-service.amp C:\Alfresco\tomcat\webapps\share.war -force
//java -jar alfresco-mmt.jar install C:\Alfresco\amps_share\alfresco-signature-service.amp C:\Alfresco\tomcat\webapps\alfresco.war -force



//java -jar alfresco-mmt.jar install C:\Alfresco\amps_share\alfresco-share-pdf-toolkit-1.0.0.amp C:\Alfresco\tomcat\webapps\share.war -force
//java -jar alfresco-mmt.jar install C:\Alfresco\amps_share\alfresco-pdf-toolkit-1.0.0.amp C:\Alfresco\tomcat\webapps\alfresco.war -force

//importPackage(java.lang);

model.ticket = session.ticket;
}
main();