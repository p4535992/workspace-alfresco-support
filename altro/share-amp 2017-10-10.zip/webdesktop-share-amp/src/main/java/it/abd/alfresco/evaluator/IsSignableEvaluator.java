package it.abd.alfresco.evaluator;


import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.alfresco.httpclient.Response;
import org.alfresco.web.evaluator.BaseEvaluator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.extensions.surf.RequestContext;
import org.springframework.extensions.surf.ServletUtil;
import org.springframework.extensions.surf.exception.ConnectorServiceException;
import org.springframework.extensions.surf.support.ThreadLocalRequestContext;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.connector.Connector;

import it.abd.alfresco.bean.Aoo;
import it.abd.alfresco.bean.ConfigurazioniBean;
import it.abd.alfresco.lib.AlfrescoLib;
import it.abd.webdesktop.client.exception.WebdesktopException;


/**
 * Un evaluator che ritorna true se il documento è firmabile cioe pdf o xml.
 */
public class IsSignableEvaluator extends BaseEvaluator {
	
	private static Log logger = LogFactory.getLog(IsSignableEvaluator.class);
	//private static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(IsSignable.class);
	
	 private final static String NODEREF = "nodeRef";
	 private final static String NODE = "node";
	 private final static String PROPERTIES = "properties";
	 private final static String DOCUMENT_TYPE = "cm:content";
	 private final static String MIMETYPE = "mimetype";
	
	Properties configurazioniBeanCompletoLocaleShare;

    @Override
    public boolean evaluate(JSONObject jsonObject) {
        try {
        	logger.fatal("START Evaluator IsSignable");
	
        	//PROPRIETA JSON OBJECT
        	
        	JSONObject node = (JSONObject) jsonObject.get(NODE);
            if (node == null)
            {
            	throw new WebdesktopException("NODE da evalutare, is NULL");
            }   
            JSONObject properties = (JSONObject) node.get(PROPERTIES);
            final String sNodeRef = (String) jsonObject.get(NODEREF);
            String nodeType = getNodeType(jsonObject);
            JSONArray nodeAspects = getNodeAspects(jsonObject);
            //JSONObject importFormats = (JSONObject)getJSONValue(getMetadata(), accessor);
            String mimetype = (String) node.get(MIMETYPE);                
 
            //PREFILTRI (FILTRI BASE CHE VELOCIZZANO IL CARICAMENTO SU SHARE)
            if(!nodeType.toLowerCase().contains(DOCUMENT_TYPE)){
            	logger.fatal("Filter node type failed : "+ nodeType + ", nodeRef : " + sNodeRef);
            	return false;
            }
            if (mimetype == null || //!importFormats.containsKey(mimetype) || 
            		(
            				!mimetype.contains("application/pdf") && 
            				!(mimetype.contains("application/xml") || mimetype.contains("text/xml"))
            		)
            	)
            {     
            	logger.fatal("Filter mimetype failed : "+mimetype + ", nodeRef : " + sNodeRef);
                return false;
            }
                       
            // UTILIZZO IL BEAN DELLE PROPRIETA DI OVVERRIDE SU SHARE PER DEI CONTROLLI PRELIMINARI LATO SHARE
            // PURTROPPO NON HO ACCESSO ALLE PROPRIETA DEGLI AOO SU ALFRESCO A MENO DI UNA CHIAMATA A UN WEBSCRIPT
            // MA POSSO FARE DEI CONTROLLI PRELIMINARI PER EVITARE CHIAMATE WEBSCRIPT NON NECESSARIE
            
        	logger.fatal("NodeRef Current PROD: "+sNodeRef);
        	if(configurazioniBeanCompletoLocaleShare==null){
        		throw new WebdesktopException("configurazioniBeanCompletoLocaleShare non e' settato su share");
        	}
        	Boolean namePropertyFirmaEnable = null;
        	if(configurazioniBeanCompletoLocaleShare.containsKey("alfresco.firma.conf.firma.enable")){
        		namePropertyFirmaEnable = Boolean.parseBoolean(String.valueOf(configurazioniBeanCompletoLocaleShare.getProperty("alfresco.firma.conf.firma.enable")));
        	}
        	if(namePropertyFirmaEnable==null){
				throw new WebdesktopException("Devi aggiungere il valore di default della proprieta' <alfresco.firma.conf.firma.enable> al webdesktop ovverride");
			}
			
			//CALL WEBSCRIPT REPO TIER
			
			final RequestContext context = ThreadLocalRequestContext.getRequestContext();			          
			if (context != null) {
				final String userId = context.getUserId();
				final Connector connector = context.getServiceRegistry().getConnectorService().getConnector("alfresco", context.getUserId(), ServletUtil.getSession());
				if (connector != null) {
					//IMPORTANTE RICORDA CHE LA PATH DELLA CALL E' RELATIVA AL PARAMETRO URL DEL WEBSCRIPT DI DESCRIZIONE
					final org.springframework.extensions.webscripts.connector.Response response = connector.call("/abd/getpropertiesaoo?nodeRefCurrent="+sNodeRef+"&tipoDropDown=CODICE_AOO");
					if (response != null) {
						 if (response.getStatus().getCode() == Status.STATUS_OK) {
							logger.fatal("RESPONSE: " + response.getResponse());									
				            try {
				                //PARSE JSON
				    			org.json.simple.parser.JSONParser p = new org.json.simple.parser.JSONParser();
				    			Object jsonCodiceAOO = p.parse(response.getResponse());
				    			if (jsonCodiceAOO instanceof org.json.simple.JSONObject)
				    			{
				    			    String codiceAOO = String.valueOf(((org.json.simple.JSONObject) jsonCodiceAOO).get("codiceAOO"));    				    			   
				    			    logger.fatal("RESULT OBJECT : "+ ((org.json.simple.JSONObject) jsonCodiceAOO).toString() +", codiceAOO : " + codiceAOO);				    			    
					                if(codiceAOO==null || codiceAOO.isEmpty()){
					    				codiceAOO = "ALFRESCO";
					    			}					    			
					    			if(codiceAOO != "ALFRESCO"){
					    				Boolean flagAOO = null;
					    				//ovverride firma aoo rispetto a quello di default dell'applicativo
					    				if(configurazioniBeanCompletoLocaleShare.containsKey("alfresco.firma.conf.firma.enable."+codiceAOO)){
					    					flagAOO = Boolean.parseBoolean(String.valueOf(configurazioniBeanCompletoLocaleShare.get("alfresco.firma.conf.firma.enable."+codiceAOO)));
						    				if(flagAOO != null){
						    					namePropertyFirmaEnable = flagAOO;
						    				}	
					    				}				    				
					    			}		
					    			return namePropertyFirmaEnable;  
				    			}else if(jsonCodiceAOO instanceof org.json.simple.JSONArray){		    							    			    
				    				org.json.simple.JSONArray jsonArrayCodiceAOO = (org.json.simple.JSONArray)jsonCodiceAOO;
				    				logger.fatal("RESULT ARRAY JSON : " + jsonArrayCodiceAOO.toString());	
				    				Map<String, String> mapAOO = new HashMap<>();
				    				for (int i = 0; i < jsonArrayCodiceAOO.size(); i++) { 
				    					org.json.simple.JSONObject json = (JSONObject) jsonArrayCodiceAOO.get(i);
				    				    String id = String.valueOf(json.get("id"));
				    				    String name = String.valueOf(json.get("name"));
				    				    mapAOO.put(id, name);
				    				}
				    				logger.fatal("MAP AOO:" + Arrays.toString(mapAOO.entrySet().toArray()));		
				    				String codiceAOO = mapAOO.get("codiceAOO");
				    				if(codiceAOO==null || codiceAOO.isEmpty()){
						    			codiceAOO = "ALFRESCO";
						    		}
				    				logger.fatal("RESULT ARRAY codiceAOO : " + codiceAOO);
						    		if(codiceAOO != "ALFRESCO"){
						    			Boolean flagAOO = null;
						    			//Nel caso delle AOO si da priorita' al valore della variabile
						    			//alfresco.firma.conf.firma.enable rispetto a alfresco.firma.conf.firma.enable.AOOX
						    			if(mapAOO.containsKey("alfresco.firma.conf.firma.enable")){
						    				flagAOO = Boolean.parseBoolean(mapAOO.get("alfresco.firma.conf.firma.enable"));
						    			}else if(mapAOO.containsKey("alfresco.firma.conf.firma.enable."+codiceAOO)){
						    				flagAOO = Boolean.parseBoolean(mapAOO.get("alfresco.firma.conf.firma.enable."+codiceAOO));
						    			}else{
						    				//nessuna proprieta di abilitazione della fima e' stata trovata
						    			}
						    			//ovverride firma aoo rispetto a quello di default dell'applicativo
						    			if(flagAOO != null){
						    				namePropertyFirmaEnable = flagAOO;
						    			}else{
						    				if(configurazioniBeanCompletoLocaleShare.containsKey("alfresco.firma.conf.firma.enable."+codiceAOO)){
						    					flagAOO = Boolean.parseBoolean(String.valueOf(configurazioniBeanCompletoLocaleShare.get("alfresco.firma.conf.firma.enable."+codiceAOO)));
						    					if(flagAOO != null)namePropertyFirmaEnable = flagAOO;
						    				}
						    			}				    				
						    		}	 
				    				return namePropertyFirmaEnable;  			    				
				    			}else{
				    				throw new WebdesktopException("Risposta JSON non gestita : " + response.getResponse());
				    			}				              
				            } catch (ParseException e) {
				            	throw new WebdesktopException("JSON Errato : " + e.toString(),e);	
							}
				        } else {
				        	throw new WebdesktopException("Call failed, code :" + response.getStatus().getCode());				            
				        }
					} else {
						throw new WebdesktopException("NO response set, is NULL");
					}
				} else {
					throw new WebdesktopException("NO connector set, is NULL");
				}
			} else {
				throw new WebdesktopException("NO share context set, is NULL");
			}			                                     
        } catch (WebdesktopException err) {
        	logger.error("IsSignable Error: " + org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(err));
            return false;
        } catch (ConnectorServiceException e){
        	logger.error("IsSignable Error: " + org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));
            return false;
		}
    }

	public void setConfigurazioniBeanCompletoLocaleShare(Properties configurazioniBeanCompletoLocaleShare) {
		this.configurazioniBeanCompletoLocaleShare = configurazioniBeanCompletoLocaleShare;
	}

    
    
}