(function () {
//    YAHOO.Bubbling.fire("registerAction",
//        {
//            actionName: "onShowCustomMessage",
//            fn: function org_alfresco_training_onShowCustomMessage(file) {
//                Alfresco.util.PopupManager.displayMessage(
//                    {
//                        text: this.msg("it.abd.sign.doclib.action.showCustomMessage.text",
//                            file.displayName, Alfresco.constants.USERNAME)
//                    });
//            }
//        });

    YAHOO.Bubbling.fire("registerAction",
        {
            actionName: "onActionSignSurfActionMultiSelect",
            fn: function onActionSignSurfActionMultiSelect(record) {
            	
			   //Verifichiamo se un nodo o piu selezionati
			   var tmpnodeRef = [];
			   if (YAHOO.lang.isArray(record))
			   {
			      for (var i = 0, il = record.length; i < il; i++)
			      {
			     	 tmpnodeRef.push(record[i].nodeRef);
			      }
			   }
			   else
			   {
			  	  tmpnodeRef.push(record.nodeRef)
			   }
			  	var jsNode = record.jsNode;
                var currentType = jsNode.type;
                var displayName = record.displayName;
                //var actionUrl = Alfresco.constants.PROXY_URI + "it/abd/doclib/action/" + jsNode.nodeRef.uri;
                //var actionUrl = Alfresco.constants.PROXY_URI + "slingshot/doclib/type/node/" + jsNode.nodeRef.uri;
                var actionUrl = YAHOO.lang.substitute(Alfresco.constants.PROXY_URI + "it/abd/action/{uri}",
                        {
                           uri : this.doclistMetadata.parent.nodeRef.replace(":/", "")
                        });
                var templateUrl = Alfresco.constants.URL_SERVICECONTEXT + "it/abd/action/abdSignActionContent";
                var itemId = jsNode.nodeRef.uri;
                /*
                this.modules.actions.genericAction(
                    {
                        success: {
                            callback: {
                                fn: function org_alfresco_training_onActionCallWebScriptSuccess(response) {
                                    Alfresco.util.PopupManager.displayPrompt(
                                        {
                                            title: this.msg("it.abd.sign.doclib.action.callWebScript.msg.success"),
                                            text: JSON.stringify(response.json),
                                            buttons: [
                                                {
                                                    text: this.msg("button.ok"),
                                                    handler: function org_alfresco_training_onActionCallWebScriptSuccess_success_ok() {
                                                        this.destroy();
                                                    },
                                                    isDefault: true
                                                },
                                                {
                                                    text: this.msg("button.cancel"),
                                                    handler: function org_alfresco_training_onActionCallWebScriptSuccess_cancel() {
                                                        this.destroy();
                                                    }
                                                }]
                                        });

                                },
                                scope: this
                            }
                        },
                        failure: {
                            //message: this.msg("it.abd.sign.doclib.action.callWebScript.msg.failure",file.displayName, Alfresco.constants.USERNAME)                       	
                        },
                        failureCallback : {
        		  			fn: function(res)
        	               {
        		  				 Alfresco.util.PopupManager.displayMessage(
        	                           {
        	                              text: this.msg("it.abd.sign.doclib.action.callWebScript.msg.failure")
        	                           });
        	               },
        	               scope: this
        		  		},
                        webscript: {
                            name: "sample/fileinfo?nodeRef={nodeRef}",
                            stem: Alfresco.constants.PROXY_URI,
                            method: Alfresco.util.Ajax.GET,
                            params: {
                                nodeRef: file.nodeRef
                            }
                        },
                        config: {}
                    });
            	*/
                //Costruisci la tua form
                this.form = new Abd.util.AjaxFormUI();
                this.form.setOptions(
                {
                   itemId : itemId,//"workspace://SpacesStore/73ddea6e-c937-4db3-af65-44c82150a72f",
                   mode : "edit",
                   htmlid : parent.id,
                   container : Dom.get(parent.id + "-container"),
                   successCallback:
                   {
                	   fn: function onActionSignSurfActionMultiSelectSuccess(response) {
                           Alfresco.util.PopupManager.displayPrompt(
                                   {
                                       title: this.msg("it.abd.sign.doclib.action.callWebScript.msg.success"),
                                       text: JSON.stringify(response.json),
                                       buttons: [
                                           {
                                               text: this.msg("button.ok"),
                                               handler: function onActionSignSurfActionMultiSelect_success_ok() {
                                                   this.destroy();
                                               },
                                               isDefault: true
                                           },
                                           {
                                               text: this.msg("button.cancel"),
                                               handler: function onActionSignSurfActionMultiSelect_cancel() {
                                                   this.destroy();
                                               }
                                           }]
                                   });
                	   }
                      //scope: parent
                   },
                   successMessage : parent._msg("message.update-success"),
                   cancelCallback:
                   {
                      fn: parent.onCreateUserFormCancelClick,
                      scope: parent
                   }
                });
                this.form.render();
                
                //Inserisci la tua richiesta in una richiesta ajax (opzionale)
                /*
            	Alfresco.util.Ajax.request({
    		  		method : Alfresco.util.Ajax.POST,
    		  		url : url,
    		  		requestContentType : Alfresco.util.Ajax.JSON,
    		  		responseContentType : Alfresco.util.Ajax.JSON,
    		  		dataObj : {
    		  			nodeRefs : tmpnodeRef
    		  		},
    		  		successCallback:
    	            {
    	               fn: function(res)
    	               {	            	  
    	                   var successCount = res.json.successCount;
    	                   var failureCount = res.json.failureCount;
    	                   var totalResults = res.json.totalResults;
    	                   var results = res.json.results;
    	                   var thefiles = "";
    		               // Did the operation NOT succeed?	                   
    		               if (!res.json.overallSuccess && successCount>0)
    		               {	                  
    		            	   for(i =0;i<results.length;i++){
    		            		   if(!results[i].success){
    		            			   thefiles = thefiles + results[i].name + "\r\n";
    		            		   }
    		            	   }
    		            	   var errormsgkey;
    		            	   if(totalResults==1){
    		            	    Alfresco.util.PopupManager.displayPrompt(
                                    {
                                        text: this.msg("selection.success.file.already.exist")
                                    });
    		            	   }else{
    		            	    Alfresco.util.PopupManager.displayPrompt(
                                    {
                                	    text: this.msg("selection.success.file.already.exist",successCount, thefiles)
                                    });
    		            	   }
    		                  return;
    		               }
    		               else if(!res.json.overallSuccess && successCount == 0){
    		               var errormsgkey;
                           if(totalResults==1){
                            errormsgkey = "selection.success.all.files.already.exist";
                           }else{
                            errormsgkey = "selection.success.all.files.already.exists";
                           }

    		            	   Alfresco.util.PopupManager.displayPrompt(
                               {
                                  text: this.msg(errormsgkey)
                               });              
    		                  return;
    		               }
    		               var msginfo;
    	            	   if(successCount==1){
    	            		   msginfo = this.msg("add.selection.success");
    	            	   }else {
    	            		   msginfo = this.msg("add.multi.selection.success", successCount);
    	            	   }
    		               Alfresco.util.PopupManager.displayMessage(
    	                   {
    	                      text: msginfo  	                      
    	                   });
    	               },
    	               scope: this
    	            },
    		  		failureCallback : {
    		  			fn: function(res)
    	               {
    		  				 Alfresco.util.PopupManager.displayMessage(
    	                           {
    	                              text: this.msg("smile.panier.add.selection.failure")
    	                           });
    	               },
    	               scope: this
    		  		}
    		  	}); 
            	*/
            
            }
        });
    
 
})();