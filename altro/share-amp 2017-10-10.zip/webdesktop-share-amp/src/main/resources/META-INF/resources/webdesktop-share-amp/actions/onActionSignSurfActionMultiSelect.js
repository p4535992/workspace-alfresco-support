(function()
{

    var mydlA_onMyEdit = function(record)
    {
    	console.error("START MULTISELECT");
         var scope = this,
            nodeRef = record.nodeRef,
            jsNode = record.jsNode;

         // Intercept before dialog show
         var doBeforeDialogShow = function mydlA_onMyEdit_doBeforeDialogShow(p_form, p_dialog)
         {
            // Dialog title
            var fileSpan = '<span class="light"> MyEdit </span>';

            //var dialogTitleSuffix = "-dialogTitle";
            var dialogTitleSuffix = "-form-container_h";
           
            Alfresco.util.populateHTML(
               [ p_dialog.id + dialogTitleSuffix , fileSpan ]
            );
         };

         //var templateUrl = YAHOO.lang.substitute(Alfresco.constants.URL_SERVICECONTEXT + "components/form?itemKind={itemKind}&itemId={itemId}&destination={destination}&mode={mode}&submitType={submitType}&formId={formId}&showCancelButton=true",
         var templateUrl = YAHOO.lang.substitute(Alfresco.constants.URL_SERVICECONTEXT + "components/form?itemKind={itemKind}&itemId={itemId}&destination={destination}&mode={mode}&formId={formId}&showCancelButton=true",
         {      	 
        	 itemKind="action",
             itemId="signSurfAction", //Repository action id = Spring Bean id 
             mode="create",
             destination=nodeRef,
             
             //Se basato su un nodo
             /*
            itemKind: "node",
            itemId: nodeRef,
            mode: "edit",
            submitType: "json",
            */
            
             //Se basato su un modello
             /*
             itemKind: "type",
             itemId: "eagle:project",
             //itemId: "cm:folder",
             destination: destination,
             mode: "create",
             submitType: "json"
             */
            //questo riprende id della form settata nel file xml di configurazione
             //se non specificato dovrebbe rpendere il valore signSurfAction dell'itemId
             //basandosi sul tag "condition"
            formId: "my-edit-form"
         });
         console.error("templateUrl: "+templateUrl);
         // Using Forms Service, so always create new instance
         var myEdit = new Alfresco.module.SimpleDialog(this.id + "-myedit-" + Alfresco.util.generateDomId());
         //var myDialog = new Alfresco.module.SimpleDialog("${args.htmlid}-myDialog");
         myEdit.setOptions(
         {
            width: "auto",
            templateUrl: templateUrl,
            actionUrl: null,
            destroyOnHide: true,
            doBeforeDialogShow:
            {
               fn: doBeforeDialogShow,
               scope: this
            },
            onSuccess:
            {
               fn: function mydlA_onMyEdit_success(response)
               {
                  var successMsg = this.msg("Success!");
                 
                  Alfresco.util.PopupManager.displayMessage(
                  {
                     text: successMsg
                  });
               },
               scope: this
            },
            onFailure:
            {
               fn: function mydLA_onMyEdit_failure(response)
               {
                  var failureMsg = this.msg("Failure!");
                
                  Alfresco.util.PopupManager.displayMessage(
                  {
                     text: failureMsg
                  });
               },
               scope: this
            }
         });
       
         myEdit.show();
     };


    YAHOO.Bubbling.fire("registerAction",
    {
        actionName: "onActionSignSurfActionMultiSelect",
        fn: mydlA_onMyEdit
    });
})();