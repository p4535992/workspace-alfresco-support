//model["fromJson"] = "Hello GetPropertiesAOO!";


