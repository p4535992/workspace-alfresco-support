function main() {
   //Vecchie versioni 3  e 4 alfresco
   //model.sessionTicket = session.getTicket();
   //Versione 5 alfresco
   model.sessionTicket = sessionticket.getTicket()
	
}
main();