package com.posidex.pgp.util;

public class PosidexConstant {

	public final static String PUBLIC_KEY = "PUBLIC_KEY";
	public final static String PRIVATE_KEY = "PRIVATE_KEY";
	public final static String SOURCE_FILE_PATH = "SOURCE_FILE_PATH";
	public final static String DECRYPT_FILE_OUTPUT_PATH = "DECRYPT_FILE_OUTPUT_PATH";
	public final static String ENCRYPT_FILE_PATH = "ENCRYPT_FILE_PATH";
	public final static String PRIVATE_FILE_PASS = "PRIVATE_FILE_PASS";
}
