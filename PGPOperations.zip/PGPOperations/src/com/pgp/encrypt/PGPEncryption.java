package com.pgp.encrypt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Properties;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;






import com..pgp.util.KeyBasedFileProcessorUtil;
import com..pgp.util.Constant;

public class PGPEncryption {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties prop=new Properties();
		try {
			File f=new File("config.prop");
			System.out.println(f.getAbsolutePath());
			prop.load(new FileInputStream(f));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileInputStream keyIn=null;
		FileOutputStream out =null;
		Security.addProvider(new BouncyCastleProvider());
		try {
			System.out.println(prop.getProperty(Constant.PUBLIC_KEY));
			keyIn = new FileInputStream(prop.getProperty(Constant.PUBLIC_KEY));
			System.out.println("Encrypt File Path :-"+prop.getProperty(Constant.ENCRYPT_FILE_PATH));
			out= new FileOutputStream(new File(prop.getProperty(Constant.ENCRYPT_FILE_PATH)));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean armor = false;
		boolean integrityCheck = false;
		PGPPublicKey pubKey = null;
		try {
			System.out.println("Reading public key.........");
			pubKey = KeyBasedFileProcessorUtil.readPublicKey(keyIn);
			System.out.println("Public Key found...........");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PGPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("File Encrypting............");
			KeyBasedFileProcessorUtil.encryptFile(out, prop.getProperty(Constant.SOURCE_FILE_PATH), pubKey, armor, integrityCheck);
			System.out.println("Encrypted File created with name of "+prop.getProperty(Constant.ENCRYPT_FILE_PATH));
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
